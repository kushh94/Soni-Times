import { useState } from "react";
import { ArrowLeft, Heart, MessageCircle, Minus, Plus } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface Product {
  id: number;
  image: string;
  brand?: string;
  model?: string;
  datePosted: string;
}

interface ProductDetailProps {
  product: Product;
  isLiked: boolean;
  onToggleLike: () => void;
  onBack: () => void;
}

export function ProductDetail({ product, isLiked, onToggleLike, onBack }: ProductDetailProps) {
  const [zoomLevel, setZoomLevel] = useState(1);
  
  const handleZoomIn = () => setZoomLevel(prev => Math.min(prev + 0.2, 2.5));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(prev - 0.2, 1));
  
  const handleWhatsAppEnquiry = () => {
    const message = encodeURIComponent(
      `Hi! I'm interested in this ${product.brand ? product.brand : 'timepiece'}${product.model ? ` ${product.model}` : ''}. Could you provide more details?`
    );
    window.open(`https://wa.me/+919664739439?text=${message}`, '_blank');
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-gray-100">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors"
        >
          <ArrowLeft size={20} className="text-gray-700" />
        </button>
        
        <h1 className="text-lg text-gray-900">Product Details</h1>
        
        <button
          onClick={onToggleLike}
          className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors"
        >
          <Heart 
            size={20} 
            className={isLiked ? "fill-red-500 text-red-500" : "text-gray-700"} 
          />
        </button>
      </div>

      {/* Product Image */}
      <div className="flex-1 overflow-hidden relative bg-gray-50">
        <div className="absolute inset-0 flex items-center justify-center">
          <div 
            className="transition-transform duration-300 ease-out"
            style={{ transform: `scale(${zoomLevel})` }}
          >
            <ImageWithFallback
              src={product.image}
              alt={`${product.brand} ${product.model}`.trim() || "Product"}
              className="max-w-full max-h-full object-contain"
            />
          </div>
        </div>
        
        {/* Zoom Controls */}
        <div className="absolute top-4 right-4 flex flex-col bg-white/90 backdrop-blur-sm rounded-lg shadow-sm overflow-hidden">
          <button
            onClick={handleZoomIn}
            className="p-3 hover:bg-gray-100 transition-colors border-b border-gray-200"
          >
            <Plus size={18} className="text-gray-700" />
          </button>
          <button
            onClick={handleZoomOut}
            className="p-3 hover:bg-gray-100 transition-colors"
          >
            <Minus size={18} className="text-gray-700" />
          </button>
        </div>
      </div>

      {/* Product Details */}
      <div className="p-6 space-y-6">
        <div>
          {product.brand && (
            <p className="text-sm text-gray-500 uppercase tracking-wide mb-2">
              {product.brand}
            </p>
          )}
          {product.model && (
            <h2 className="text-xl text-gray-900 mb-3">
              {product.model}
            </h2>
          )}
          {product.price && (
            <p className="text-lg text-gray-900 mb-3">
              {product.price}
            </p>
          )}
          <p className="text-sm text-gray-500">
            Posted on {product.datePosted}
          </p>
        </div>

        {/* WhatsApp Enquiry Button */}
        <button
          onClick={handleWhatsAppEnquiry}
          className="w-full bg-green-500 hover:bg-green-600 text-white rounded-2xl py-4 flex items-center justify-center gap-3 transition-colors shadow-sm"
        >
          <MessageCircle size={20} />
          <span>Enquire via WhatsApp</span>
        </button>
      </div>
    </div>
  );
}