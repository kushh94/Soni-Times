import { Heart } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface ProductCardProps {
  id: number;
  image: string;
  brand?: string;
  model?: string;
  datePosted: string;
  price?: string;
  isLiked?: boolean;
  onToggleLike?: (id: number) => void;
  onClick?: () => void;
}

export function ProductCard({ 
  id, 
  image, 
  brand, 
  model, 
  datePosted, 
  price,
  isLiked = false, 
  onToggleLike,
  onClick 
}: ProductCardProps) {
  const handleLikeClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleLike?.(id);
  };

  return (
    <div 
      onClick={onClick}
      className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow duration-300 cursor-pointer"
    >
      <div className="relative aspect-square overflow-hidden">
        <ImageWithFallback
          src={image}
          alt={`${brand} ${model}`.trim() || "Product"}
          className="w-full h-full object-cover"
        />
        <button
          onClick={handleLikeClick}
          className="absolute top-3 right-3 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-sm hover:bg-white transition-colors"
        >
          <Heart 
            size={16} 
            className={isLiked ? "fill-red-500 text-red-500" : "text-gray-600"} 
          />
        </button>
      </div>
      
      <div className="p-4">
        {brand && (
          <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">
            {brand}
          </p>
        )}
        {model && (
          <h3 className="text-gray-900 mb-2 line-clamp-2">
            {model}
          </h3>
        )}
        {price && (
          <p className="text-gray-900 mb-2">
            {price}
          </p>
        )}
        <p className="text-xs text-gray-400">
          {datePosted}
        </p>
      </div>
    </div>
  );
}