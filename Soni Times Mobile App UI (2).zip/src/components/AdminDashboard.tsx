import { useState } from "react";
import { Plus, Camera, Upload, Trash2, Edit, LogOut } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface Product {
  id: number;
  image: string;
  brand?: string;
  model?: string;
  datePosted: string;
  price?: string;
  category: 'wrist-watch' | 'wall-clock';
}

interface AdminDashboardProps {
  products: Product[];
  onAddProduct: (product: Omit<Product, 'id' | 'datePosted'>) => void;
  onDeleteProduct: (id: number) => void;
  onLogout: () => void;
}

export function AdminDashboard({ products, onAddProduct, onDeleteProduct, onLogout }: AdminDashboardProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newProduct, setNewProduct] = useState({
    image: "",
    brand: "",
    model: "",
    price: "",
    category: "wrist-watch" as 'wrist-watch' | 'wall-clock'
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setNewProduct(prev => ({ ...prev, image: e.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newProduct.image) {
      onAddProduct(newProduct);
      setNewProduct({ image: "", brand: "", model: "", price: "", category: "wrist-watch" });
      setShowAddForm(false);
    }
  };

  return (
    <div className="flex-1 bg-gray-50">
      {/* Header */}
      <div className="bg-white px-6 py-4 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl text-gray-900 mb-1">Admin Dashboard</h1>
            <p className="text-sm text-gray-500">{products.length} products uploaded</p>
          </div>
          <button
            onClick={onLogout}
            className="p-2 text-gray-500 hover:text-red-500 transition-colors"
          >
            <LogOut size={20} />
          </button>
        </div>
      </div>

      <div className="p-6 pb-24">
        {/* Add Product Button */}
        {!showAddForm && (
          <button
            onClick={() => setShowAddForm(true)}
            className="w-full bg-gray-900 hover:bg-gray-800 text-white rounded-2xl py-4 flex items-center justify-center gap-2 mb-6 transition-colors"
          >
            <Plus size={20} />
            <span>Add New Product</span>
          </button>
        )}

        {/* Add Product Form */}
        {showAddForm && (
          <div className="bg-white rounded-2xl p-6 mb-6 shadow-sm border border-gray-100">
            <h3 className="text-lg text-gray-900 mb-4">Add New Product</h3>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Image Upload */}
              <div>
                <label className="block text-sm text-gray-700 mb-2">Product Image *</label>
                {newProduct.image ? (
                  <div className="relative">
                    <ImageWithFallback
                      src={newProduct.image}
                      alt="Preview"
                      className="w-full h-48 object-cover rounded-xl"
                    />
                    <button
                      type="button"
                      onClick={() => setNewProduct(prev => ({ ...prev, image: "" }))}
                      className="absolute top-2 right-2 w-8 h-8 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ) : (
                  <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center">
                    <div className="flex flex-col items-center gap-2">
                      <Upload size={24} className="text-gray-400" />
                      <p className="text-sm text-gray-500">Upload image</p>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                        id="image-upload"
                      />
                      <label
                        htmlFor="image-upload"
                        className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg cursor-pointer transition-colors"
                      >
                        Choose File
                      </label>
                    </div>
                  </div>
                )}
              </div>

              {/* Brand Name */}
              <div>
                <label className="block text-sm text-gray-700 mb-2">Brand Name</label>
                <input
                  type="text"
                  value={newProduct.brand}
                  onChange={(e) => setNewProduct(prev => ({ ...prev, brand: e.target.value }))}
                  placeholder="e.g., Rolex, Seiko"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
                />
              </div>

              {/* Model Name */}
              <div>
                <label className="block text-sm text-gray-700 mb-2">Model Name</label>
                <input
                  type="text"
                  value={newProduct.model}
                  onChange={(e) => setNewProduct(prev => ({ ...prev, model: e.target.value }))}
                  placeholder="e.g., Submariner, Wall Clock Classic"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-sm text-gray-700 mb-2">Category *</label>
                <select
                  value={newProduct.category}
                  onChange={(e) => setNewProduct(prev => ({ ...prev, category: e.target.value as 'wrist-watch' | 'wall-clock' }))}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
                >
                  <option value="wrist-watch">Wrist Watch</option>
                  <option value="wall-clock">Wall Clock</option>
                </select>
              </div>

              {/* Price */}
              <div>
                <label className="block text-sm text-gray-700 mb-2">Price</label>
                <input
                  type="text"
                  value={newProduct.price}
                  onChange={(e) => setNewProduct(prev => ({ ...prev, price: e.target.value }))}
                  placeholder="e.g., ₹50,000, Contact for price"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
                />
              </div>

              {/* Form Actions */}
              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  disabled={!newProduct.image}
                  className="flex-1 bg-gray-900 hover:bg-gray-800 disabled:bg-gray-400 text-white rounded-xl py-3 transition-colors text-center"
                >
                  Post Product
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-6 py-3 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-xl transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Products List */}
        <div className="space-y-4">
          <h3 className="text-lg text-gray-900">Uploaded Products</h3>
          
          {products.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
              <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                <Camera size={24} className="text-gray-400" />
              </div>
              <p className="text-gray-500">No products uploaded yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {products.map((product) => (
                <div key={product.id} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex items-center gap-4">
                  <ImageWithFallback
                    src={product.image}
                    alt={`${product.brand} ${product.model}`.trim()}
                    className="w-16 h-16 object-cover rounded-xl"
                  />
                  
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        {product.brand && (
                          <p className="text-xs text-gray-500 uppercase tracking-wide">
                            {product.brand}
                          </p>
                        )}
                        <h4 className="text-gray-900">
                          {product.model || "Untitled Product"}
                        </h4>
                        <p className="text-xs text-blue-600 capitalize">{product.category.replace('-', ' ')}</p>
                        <p className="text-xs text-gray-400">{product.datePosted}</p>
                        {product.price && (
                          <p className="text-sm text-gray-600 mt-1">{product.price}</p>
                        )}
                      </div>
                      
                      <button
                        onClick={() => onDeleteProduct(product.id)}
                        className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}