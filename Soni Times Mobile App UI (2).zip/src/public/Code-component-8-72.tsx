{
  "name": "Soni Times - Premium Timepieces",
  "short_name": "Soni Times",
  "description": "Browse and shop premium watches and wall clocks from Soni Times collection",
  "start_url": "/",
  "display": "standalone",
  "orientation": "portrait",
  "theme_color": "#030213",
  "background_color": "#ffffff",
  "categories": ["shopping", "lifestyle"],
  "lang": "en",
  "dir": "ltr",
  "scope": "/",
  "icons": [
    {
      "src": "/icons/icon-72x72.png",
      "sizes": "72x72",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-96x96.png",
      "sizes": "96x96",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-128x128.png",
      "sizes": "128x128",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-144x144.png",
      "sizes": "144x144",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-152x152.png",
      "sizes": "152x152",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-192x192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-384x384.png",
      "sizes": "384x384",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-512x512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "maskable any"
    }
  ],
  "screenshots": [
    {
      "src": "/screenshots/mobile-1.png",
      "sizes": "390x844",
      "type": "image/png",
      "form_factor": "narrow",
      "label": "Home screen showing watch collection"
    },
    {
      "src": "/screenshots/mobile-2.png",
      "sizes": "390x844",
      "type": "image/png",
      "form_factor": "narrow",
      "label": "Product detail view"
    }
  ],
  "shortcuts": [
    {
      "name": "Browse Wrist Watches",
      "short_name": "Wrist Watches",
      "description": "View our collection of premium wrist watches",
      "url": "/?category=wrist-watch",
      "icons": [
        {
          "src": "/icons/watch-shortcut.png",
          "sizes": "96x96"
        }
      ]
    },
    {
      "name": "Browse Wall Clocks",
      "short_name": "Wall Clocks",
      "description": "View our collection of elegant wall clocks",
      "url": "/?category=wall-clock",
      "icons": [
        {
          "src": "/icons/clock-shortcut.png",
          "sizes": "96x96"
        }
      ]
    },
    {
      "name": "Contact Us",
      "short_name": "Contact",
      "description": "Get in touch with Soni Times",
      "url": "/?screen=contact",
      "icons": [
        {
          "src": "/icons/contact-shortcut.png",
          "sizes": "96x96"
        }
      ]
    }
  ]
}